<?php

return [
    'build_path' => 'build',
];